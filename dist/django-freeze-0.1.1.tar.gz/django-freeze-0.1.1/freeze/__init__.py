# -*- coding: utf-8 -*-

from freeze.version import __version__

